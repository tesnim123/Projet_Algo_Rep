// Nouveau client.c avec noms de fonctions modifiés et synchronisation par message "NEXT" du serveur
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <windows.h>

#define PORT 5000
#define MAX_MSG 1024
#define N_PROCESSES 4
#define N_ITERATIONS 5

// Definition des horloges

typedef struct {
    int value;
} ScalarClock;

typedef struct {
    int vector[N_PROCESSES];
    int pid;
} VectorClock;

typedef struct {
    int matrix[N_PROCESSES][N_PROCESSES];
    int pid;
} MatrixClock;

void initialiserHorlogeScalaire(ScalarClock *clock) { clock->value = 0; }
void initialiserHorlogeVectorielle(VectorClock *clock, int pid) {
    for (int i = 0; i < N_PROCESSES; i++) clock->vector[i] = 0;
    clock->pid = pid;
}
void initialiserHorlogeMatricielle(MatrixClock *clock, int pid) {
    for (int i = 0; i < N_PROCESSES; i++)
        for (int j = 0; j < N_PROCESSES; j++)
            clock->matrix[i][j] = 0;
    clock->pid = pid;
}

void incrementerHorlogeScalaire(ScalarClock *clock) {
    clock->value++;
    printf("Horloge scalaire mise a jour: %d\n", clock->value);
}
void incrementerHorlogeVectorielle(VectorClock *clock) {
    clock->vector[clock->pid]++;
    printf("Horloge vectorielle mise a jour: [%d,%d,%d,%d]\n",
           clock->vector[0], clock->vector[1], clock->vector[2], clock->vector[3]);
}
void incrementerHorlogeMatricielle(MatrixClock *clock) {
    clock->matrix[clock->pid][clock->pid]++;
    printf("Horloge matricielle mise a jour:\n");
    for (int i = 0; i < N_PROCESSES; i++) {
        printf("[");
        for (int j = 0; j < N_PROCESSES; j++) {
            printf("%d", clock->matrix[i][j]);
            if (j < N_PROCESSES - 1) printf(",");
        }
        printf("]\n");
    }
}

ScalarClock horlogeScalaire;
VectorClock horlogeVectorielle;
MatrixClock horlogeMatricielle;

void effectuerOperationsLocales(int pid) {
    printf("Processus %d: Execution locale...\n", pid);
    int a = rand() % 100, b = rand() % 100;
    printf("Resultat: %d\n", (a + b) * 2 - a);
}

void fusionnerHorlogeScalaire(ScalarClock *clock, int valeurRecue) {
    if (clock->value < valeurRecue) {
        clock->value = valeurRecue;
    }
    incrementerHorlogeScalaire(clock);
}

void fusionnerHorlogeVectorielle(VectorClock *clock, int *vecteurRecu) {
    for (int i = 0; i < N_PROCESSES; i++) {
        if (clock->vector[i] < vecteurRecu[i])
            clock->vector[i] = vecteurRecu[i];
    }
    incrementerHorlogeVectorielle(clock);
}

void fusionnerHorlogeMatricielle(MatrixClock *clock, int matriceRecue[N_PROCESSES][N_PROCESSES], int id_processus, int id_emetteur) {
    printf("\n[Processus %d] Tentative de fusion avec message de P%d :\n", id_processus, id_emetteur);

    // Vérifier la condition de délivrance : pour tout k ≠ i,j, Em[k][i] ≤ HMi[k][i]
    char id_str[10];  // Assure-toi que la taille est suffisante
    snprintf(id_str, sizeof(id_str), "%d", id_emetteur);  // Convertir en chaîne

    // Extraire le premier caractère
    char first_digit = id_str[0];

    // Convertir ce caractère en entier
    int first_digit_int = first_digit - '0';  // '0' a la valeur ASCII de 48, donc soustraire '0' pour obtenir l'entier

    // Afficher ou utiliser first_digit_int dans la fonction
    

    // Délivrance du message
    printf("Message delivre. Mise a jour de l'horloge :\n");

    // HMi[j][i] += 1 (réception)
    clock->matrix[id_processus][id_emetteur]++;

    // HMi[i][i] += 1 (événement réception)
    clock->matrix[id_processus][id_processus]++;
    
    // Pour tout k ≠ i,j et l ≠ i : HMi[k][l] = max(HMi[k][l], Em[k][l])
    for (int k = 0; k < N_PROCESSES; k++) {
        for (int l = 0; l < N_PROCESSES; l++) {
            // Exclure (i, i) et (j, i)
            
            
                
                
                int old = clock->matrix[k][l];
                int new_val = (matriceRecue[k][l] > old) ? matriceRecue[k][l] : old;
                if (new_val != old) {
                    printf("Mise à jour horloge[%d][%d] : %d → %d\n", k, l, old, new_val);
                }
                clock->matrix[k][l] = new_val;
            
        }
    }
    

    // Affichage final
    printf("[Processus %d] Horloge matricielle apres fusion :\n", id_processus);
    for (int i = 0; i < N_PROCESSES; i++) {
        for (int j = 0; j < N_PROCESSES; j++) {
            printf("%2d ", clock->matrix[i][j]);
        }
        printf("\n");
    }
}
void envoyerHorlogeMatricielle(MatrixClock *clock, int id_processus, int id_destinataire, int buffer[N_PROCESSES][N_PROCESSES]) {
    printf("\n[Processus %d] Preparation de l'envoi vers P%d\n", id_processus, id_destinataire);

    // HMi[i][i] += 1 (événement d'envoi)
    clock->matrix[id_processus][id_processus]++;

    // HMi[i][j] += 1 (on marque qu'on a envoyé à j)
    clock->matrix[id_processus][id_destinataire]++;

    // Copier la matrice actuelle dans le buffer à envoyer (Em = HMi)
    for (int i = 0; i < N_PROCESSES; i++) {
        for (int j = 0; j < N_PROCESSES; j++) {
            buffer[i][j] = clock->matrix[i][j];
        }
    }

    // Affichage de l'horloge après envoi
    printf("[Processus %d] Horloge apres envoi :\n", id_processus);
    for (int i = 0; i < N_PROCESSES; i++) {
        for (int j = 0; j < N_PROCESSES; j++) {
            printf("%2d ", clock->matrix[i][j]);
        }
        printf("\n");
    }
}


void transmettreMessage(int pid, int dest, int typeHorloge, SOCKET sock, 
    int valeurRecue, int *vecteurRecu, int matriceRecue[N_PROCESSES][N_PROCESSES], int expediteur) {

    char msg[MAX_MSG];

    if (typeHorloge == 0) {
        incrementerHorlogeScalaire(&horlogeScalaire);
    } else if (typeHorloge == 1) {
        fusionnerHorlogeVectorielle(&horlogeVectorielle, vecteurRecu);
    } else {
        // Préparer une matrice à envoyer
        int matriceAEnvoyer[N_PROCESSES][N_PROCESSES];
        envoyerHorlogeMatricielle(&horlogeMatricielle, pid, dest, matriceAEnvoyer);
    }

    snprintf(msg, MAX_MSG, "FROM %d TO %d | HORLOGE:", pid, dest);
    if (typeHorloge == 0) {
        char hor[64]; sprintf(hor, " S %d", horlogeScalaire.value);
        strcat(msg, hor);
    } else if (typeHorloge == 1) {
        char hor[128];
        sprintf(hor, " V [%d,%d,%d,%d]", horlogeVectorielle.vector[0], horlogeVectorielle.vector[1], horlogeVectorielle.vector[2], horlogeVectorielle.vector[3]);
        strcat(msg, hor);
    } else {
        char hor[1024];
        strcat(msg, " M [");
        for (int i = 0; i < N_PROCESSES; i++) {
            for (int j = 0; j < N_PROCESSES; j++) {
                char num[6];
                sprintf(num, "%d", horlogeMatricielle.matrix[i][j]);
                strcat(msg, num);
                if (j < N_PROCESSES - 1) strcat(msg, ",");
            }
            if (i < N_PROCESSES - 1) strcat(msg, ";");
        }
        strcat(msg, "]");
    }
    
    send(sock, msg, strlen(msg), 0);
    printf("[Client %d] envoi -> %d: %s\n", pid, dest, msg);
}


void recevoirMessage(int pid, int typeHorloge, SOCKET sock, int from_pid) {
    char buffer[MAX_MSG] = {0};
    int valread;
    while (1) {
        valread = recv(sock, buffer, MAX_MSG, 0);
        if (valread > 0) {
            int src = -1;
            sscanf(buffer, "FROM %d TO", &src);
            if (src == from_pid) {
                printf("[Client %d] recu de %d: %s\n", pid, src, buffer);

                if (typeHorloge == 0) {
                    int valeurRecue = 0;
                    sscanf(buffer, "FROM %d TO %d | HORLOGE: S %d", &src, &pid, &valeurRecue);
                    fusionnerHorlogeScalaire(&horlogeScalaire, valeurRecue);
                    printf("valeur de received value %d:\n", valeurRecue); 
                    printf("Message recu : %s\n", buffer);
                    printf("[Client %d] Horloge scalaire apres fusion: %d\n", pid, horlogeScalaire.value);
                } else if (typeHorloge == 1) {
                    int vecteurRecu[N_PROCESSES] = {0};
                    sscanf(buffer, "FROM %d TO %d | HORLOGE: V [%d,%d,%d,%d]", 
                           &src, &pid, 
                           &vecteurRecu[0], &vecteurRecu[1], 
                           &vecteurRecu[2], &vecteurRecu[3]);
                    fusionnerHorlogeVectorielle(&horlogeVectorielle, vecteurRecu);
                    printf("[Client %d] Horloge vectorielle apres fusion: [%d, %d, %d, %d]\n", pid,
                           horlogeVectorielle.vector[0], horlogeVectorielle.vector[1], 
                           horlogeVectorielle.vector[2], horlogeVectorielle.vector[3]);
                        } else if (typeHorloge == 2) {
                            int matriceRecue[N_PROCESSES][N_PROCESSES] = {0};
                        
                            sscanf(buffer, "FROM %d TO %d | HORLOGE: M [%d,%d,%d,%d;%d,%d,%d,%d;%d,%d,%d,%d;%d,%d,%d,%d]",
                                   &src, &pid,
                                   &matriceRecue[0][0], &matriceRecue[0][1], &matriceRecue[0][2], &matriceRecue[0][3],
                                   &matriceRecue[1][0], &matriceRecue[1][1], &matriceRecue[1][2], &matriceRecue[1][3],
                                   &matriceRecue[2][0], &matriceRecue[2][1], &matriceRecue[2][2], &matriceRecue[2][3],
                                   &matriceRecue[3][0], &matriceRecue[3][1], &matriceRecue[3][2], &matriceRecue[3][3]);
                        
                            fusionnerHorlogeMatricielle(&horlogeMatricielle, matriceRecue,pid ,src);
                        
                            printf("[Client %d] Horloge matricielle apres fusion :\n", pid);
                            for (int i = 0; i < N_PROCESSES; i++) {
                                for (int j = 0; j < N_PROCESSES; j++) {
                                    printf("%d ", horlogeMatricielle.matrix[i][j]);
                                }
                                printf("\n");
                            }
                        }
                        
                break;
            }
        }
        Sleep(100);
    }
}

void attendreProchainSignal(SOCKET sock) {
    char buffer[MAX_MSG] = {0};
    int valread;
    while (1) {
        valread = recv(sock, buffer, MAX_MSG, 0);
        if (valread > 0 && strstr(buffer, "NEXT") != NULL) {
            printf("[Client] Recu signal NEXT, passage a l'iteration suivante\n");
            break;
        }
        Sleep(100);
    }
}

typedef struct {
    int envoyer_a;
    int attendre_de;
} Scenario;

Scenario scenarios[N_ITERATIONS][N_PROCESSES] = {
    {{1, 3}, {2, 0}, {3, 1}, {0, 2}},
    {{2, 2}, {3, 3}, {0, 0}, {1, 1}},
    {{3, 1}, {0, 2}, {1, 3}, {2, 0}},
    {{1, 3}, {2, 0}, {3, 1}, {0, 2}},
    {{-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}}
};

int main(int argc, char *argv[]) {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0) return 1;
    if (argc != 3) {
        printf("Usage: %s <pid> <clock_type>\n", argv[0]);
        return 1;
    }

    int pid = atoi(argv[1]);
    int typeHorloge = atoi(argv[2]);

    if (typeHorloge == 0) initialiserHorlogeScalaire(&horlogeScalaire);
    else if (typeHorloge == 1) initialiserHorlogeVectorielle(&horlogeVectorielle, pid);
    else initialiserHorlogeMatricielle(&horlogeMatricielle, pid);

    int valeurRecue = 0;
    int vecteurRecu[N_PROCESSES] = {0};
    int matriceRecue[N_PROCESSES][N_PROCESSES] = {{0}};

    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        printf("Connexion echouee\n"); return 1;
    }

    for (int it = 0; it < N_ITERATIONS; it++) {
        printf("\n[Client %d] Iteration %d\n", pid, it + 1);
        effectuerOperationsLocales(pid); 

        if (typeHorloge == 0) incrementerHorlogeScalaire(&horlogeScalaire);
        else if (typeHorloge == 1) incrementerHorlogeVectorielle(&horlogeVectorielle);
        else incrementerHorlogeMatricielle(&horlogeMatricielle);

        if ((it == 0 && pid == 0) ||
            (it == 1 && (pid == 0 || pid == 1)) ||
            (it == 2 && (pid == 0 || pid == 1 || pid == 2)) ||
            (it == 3 && pid == 0)) {
            if (scenarios[it][pid].envoyer_a != -1) {
                transmettreMessage(pid, scenarios[it][pid].envoyer_a, typeHorloge, sock,
                                valeurRecue, vecteurRecu, matriceRecue,pid);
            }

            if (scenarios[it][pid].attendre_de != -1) {
                recevoirMessage(pid, typeHorloge, sock, scenarios[it][pid].attendre_de);
            }
        } else {
            if (scenarios[it][pid].attendre_de != -1) {
                recevoirMessage(pid, typeHorloge, sock, scenarios[it][pid].attendre_de);
            }

            if (scenarios[it][pid].envoyer_a != -1) {
                transmettreMessage(pid, scenarios[it][pid].envoyer_a, typeHorloge, sock,
                                valeurRecue, vecteurRecu, matriceRecue,pid);
            }
        }

        attendreProchainSignal(sock);
    }

    closesocket(sock);
    WSACleanup();
    return 0;
}
