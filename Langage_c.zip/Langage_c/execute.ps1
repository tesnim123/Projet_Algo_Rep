# Chemin vers l'exécutable client
$client = ".\client.exe"

# Type d'horloge : 0 = scalaire, 1 = vectorielle, 2 = matricielle
$clockType = 2

# Lancer les 4 clients en parallèle avec IDs de 0 à 3
for ($i = 0; $i -lt 4; $i++) {
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "$client $i $clockType"
}
