#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <windows.h>

// Définition des constantes pour la configuration du serveur
#define PORT 5000            // Port d'écoute du serveur
#define MAX_MSG 1024         // Taille maximale des messages
#define MAX_CLIENTS 4        // Nombre maximum de clients autorisés à se connecter
#define MAX_ITERATIONS 5     // Nombre d'itérations maximum pour chaque client

// Déclarations des fonctions utilisées dans le programme
void initialiser_winsock();
SOCKET creer_socket_serveur();
void lier_socket(SOCKET server_fd, struct sockaddr_in* address);
void attendre_connexions(SOCKET server_fd, SOCKET client_sockets[], int* connected_clients);
void gerer_iterations(SOCKET client_sockets[]);

int main() {
    WSADATA wsaData;
    SOCKET server_fd, client_sockets[MAX_CLIENTS] = {0}; // Tableau pour stocker les sockets des clients
    struct sockaddr_in address; 
    int connected_clients = 0;  // Compteur de clients connectés

    // Initialisation de la bibliothèque Winsock
    initialiser_winsock();

    // Création du socket serveur
    server_fd = creer_socket_serveur();

    // Configuration de l'adresse du serveur
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;  // Accepte les connexions sur toutes les interfaces réseau
    address.sin_port = htons(PORT);        // Conversion du port en format réseau

    // Lier le socket à l'adresse et commencer à écouter
    lier_socket(server_fd, &address);

    // Attendre que les clients se connectent
    attendre_connexions(server_fd, client_sockets, &connected_clients);

    // Message indiquant que tous les clients sont connectés
    printf("Tous les clients sont connectes. Debut du traitement.\n");

    // Gérer les itérations avec les clients connectés
    gerer_iterations(client_sockets);

    // Message indiquant la fin des itérations
    printf("[Serveur] Toutes les iterations terminees.\n");

    // Fermeture du socket serveur et nettoyage de Winsock
    closesocket(server_fd);
    WSACleanup();
    return 0;
}

// Fonction pour initialiser Winsock
void initialiser_winsock() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("Erreur d'initialisation Winsock\n");
        exit(1);  // Quitter en cas d'échec d'initialisation
    }
}

// Fonction pour créer le socket du serveur
SOCKET creer_socket_serveur() {
    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0); // Création d'un socket TCP
    if (sock == INVALID_SOCKET) {
        perror("Erreur de socket");
        WSACleanup();
        exit(1);  // Quitter en cas d'échec de la création du socket
    }
    return sock;
}

// Fonction pour lier le socket à l'adresse et écouter les connexions
void lier_socket(SOCKET server_fd, struct sockaddr_in* address) {
    // Lier le socket à l'adresse spécifiée
    if (bind(server_fd, (struct sockaddr*)address, sizeof(*address)) == SOCKET_ERROR) {
        perror("Erreur de bind");
        closesocket(server_fd);
        WSACleanup();
        exit(1);  // Quitter en cas d'échec de bind
    }
    // Mettre le serveur en mode écoute
    if (listen(server_fd, MAX_CLIENTS) == SOCKET_ERROR) {
        perror("Erreur de listen");
        closesocket(server_fd);
        WSACleanup();
        exit(1);  // Quitter en cas d'échec de listen
    }
    printf("Serveur en ecoute sur le port %d...\n", PORT);  // Message d'écoute
}

// Fonction pour accepter les connexions des clients
void attendre_connexions(SOCKET server_fd, SOCKET client_sockets[], int* connected_clients) {
    struct sockaddr_in client_addr;
    int addrlen = sizeof(client_addr);

    // Accepter les connexions tant qu'il y a de la place pour des clients
    while (*connected_clients < MAX_CLIENTS) {
        SOCKET new_socket = accept(server_fd, (struct sockaddr*)&client_addr, &addrlen); // Accepter la connexion d'un client
        if (new_socket != INVALID_SOCKET) {
            // Chercher un emplacement libre dans le tableau des sockets des clients
            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client_sockets[i] == 0) {
                    client_sockets[i] = new_socket;  // Ajouter le client à l'emplacement libre
                    (*connected_clients)++;  // Incrémenter le compteur de clients connectés
                    printf("Client connecte a l'indice %d (%d/%d)\n", i, *connected_clients, MAX_CLIENTS);  // Affichage de l'état de la connexion
                    break;
                }
            }
        }
    }
}

// Fonction pour gérer les itérations des clients
void gerer_iterations(SOCKET client_sockets[]) {
    int current_iteration = 0;
    int etape_client[MAX_CLIENTS] = {0};  // Tableau pour suivre l'état des clients dans chaque itération
    char buffer[MAX_MSG];

    // Boucle principale qui gère les itérations
    while (current_iteration < MAX_ITERATIONS) {
        fd_set readfds;
        FD_ZERO(&readfds);
        SOCKET max_sd = 0;

        // Ajouter les sockets des clients à l'ensemble readfds pour surveiller les messages entrants
        for (int i = 0; i < MAX_CLIENTS; i++) {
            SOCKET s = client_sockets[i];
            if (s > 0) {
                FD_SET(s, &readfds);
                if (s > max_sd) max_sd = s;  // Déterminer la socket avec le plus grand descripteur
            }
        }

        struct timeval tv;
        tv.tv_sec = 15;  // Temps d'attente pour la sélection
        tv.tv_usec = 0;

        int activity = select(max_sd + 1, &readfds, NULL, NULL, &tv);  // Sélectionner les sockets avec activité
        if (activity < 0 && (WSAGetLastError() != WSAEINTR)) {
            printf("Erreur de select\n");
            break;  // Quitter en cas d'erreur de select
        }

        if (activity == 0) continue;  // Timeout, recommencer la boucle

        // Vérifier les clients qui ont envoyé des messages
        for (int i = 0; i < MAX_CLIENTS; i++) {
            SOCKET s = client_sockets[i];
            if (FD_ISSET(s, &readfds)) {
                int valread = recv(s, buffer, MAX_MSG - 1, 0);  // Recevoir le message du client
                if (valread <= 0) {
                    printf("Client %d deconnecte.\n", i);
                    closesocket(s);  // Fermer la connexion du client
                    client_sockets[i] = 0;  // Libérer l'emplacement du client
                } else {
                    buffer[valread] = '\0';  // Ajouter un caractère de fin de chaîne
                    printf("Message recu: %s\n", buffer);

                    // Extraction des informations de transfert
                    int from = -1, to = -1;
                    sscanf(buffer, "FROM %d TO %d", &from, &to);

                    // Transfert du message au client destination
                    if (to >= 0 && to < MAX_CLIENTS && client_sockets[to] != 0) {
                        printf("[Serveur] Transfert de %d a %d\n", from, to);
                        send(client_sockets[to], buffer, strlen(buffer), 0);
                    }

                    // Avancer à l'étape suivante pour le client
                    if (etape_client[i] == current_iteration) {
                        etape_client[i]++;
                        printf("[Serveur] Client %d a fini iteration %d\n", i, current_iteration);
                    }
                }
            }
        }

        // Vérifier si tous les clients ont terminé l'itération
        int tous_fini = 1;
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (etape_client[i] <= current_iteration) {
                tous_fini = 0;
                break;
            }
        }

        // Passer à l'itération suivante si tous les clients ont terminé
        if (tous_fini) {
            current_iteration++;
            printf("[Serveur] Tous les clients ont fini l'iteration %d\n", current_iteration - 1);
            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client_sockets[i] != 0) {
                    send(client_sockets[i], "NEXT", strlen("NEXT"), 0);  // Annoncer la prochaine itération
                }
            }
        }
    }
}
