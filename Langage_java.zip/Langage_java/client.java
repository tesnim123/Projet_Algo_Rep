// Importation des bibliothèques nécessaires pour les opérations d'entrées/sorties et la gestion des sockets réseau.
import java.io.*;
import java.net.*;

public class client {
    // Définition de l'adresse du serveur et du port pour la connexion.
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;
    // Déclaration d'un PrintWriter pour envoyer des messages au serveur.
    private static PrintWriter serverOut; // <== AJOUT

    // Objet pour synchroniser les threads, utilisé pour gérer la réception des messages entre les clients.
    private static final Object lock = new Object();
    private static boolean messageReceived = false;

    // Identifiant unique du client.
    private static int id;
    // Sockets nécessaires pour recevoir des connexions de pairs.
    private static ServerSocket selfSocket;
    // Horloge logique du client initialisée à 0.
    private static int logicalClock = 0;

    public static void main(String[] args) throws IOException {
        // Récupération de l'identifiant du client à partir des arguments de ligne de commande.
        id = Integer.parseInt(args[0]);
        System.out.println("Client " + id + " demarre");

        // Création d'une connexion vers le serveur en utilisant l'adresse et le port définis plus haut.
        Socket serverSocket = new Socket(SERVER_ADDRESS, SERVER_PORT);
        // Création d'un BufferedReader pour lire les messages envoyés par le serveur.
        BufferedReader serverIn = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
        // Initialisation du PrintWriter pour envoyer des messages au serveur.
        serverOut = new PrintWriter(serverSocket.getOutputStream(), true); // <== AJOUT

        // Le port pour chaque client est déterminé par son identifiant.
        int clientPort = 2000 + id;
        // Création d'un ServerSocket pour accepter des connexions des autres clients.
        selfSocket = new ServerSocket(clientPort);
        
        // Démarrage d'un thread pour écouter les connexions entrantes des autres clients.
        new Thread(() -> {
            while (true) {
                try {
                    // Acceptation d'une connexion d'un autre client.
                    Socket peer = selfSocket.accept();
                    // Lancement d'un nouveau thread pour gérer cette connexion.
                    new Thread(new PeerHandler(peer)).start();
                } catch (IOException ignored) {}
            }
        }).start();

        // Boucle pour lire les messages envoyés par le serveur.
        while (true) {
            String msg = serverIn.readLine();
            if (msg == null || msg.equals("END")) break;

            // Si le message est un signal "START" suivi de l'itération, on lance la gestion de l'itération.
            if (msg.startsWith("START")) {
                int iteration = Integer.parseInt(msg.split(" ")[1]);
                handleIteration(iteration);
            }
        }

        // Fermeture des sockets après la fin de la communication.
        serverSocket.close();
        selfSocket.close();
    }

    // Méthode pour gérer chaque itération de l'exécution.
    private static void handleIteration(int iteration) {
        System.out.println("Client " + id + " commence literation " + iteration);
        // Incrémentation de l'horloge logique pour l'événement local.
        logicalClock++; // événement local
        System.out.println("Client " + id + " instruction locale [horloge: " + logicalClock + "]");

        try {
            // Gestion des différents comportements en fonction de l'itération.
            if (iteration == 1) iteration1();
            else if (iteration == 2) iteration2();
            else if (iteration == 3) iteration3();
            else if (iteration == 4) iteration4();
            else if (iteration == 5) {} // uniquement locale

            // Envoi d'un message au serveur pour signaler la fin de l'itération.
            serverOut.println("DONE");

        } catch (Exception e) {
            // En cas d'erreur, on affiche la trace de la pile.
            e.printStackTrace();
        }
    }

    // Méthode pour gérer la première itération du processus de communication entre clients.
    private static void iteration1() throws IOException {
        if (id == 0) {
            sendTo(1);
            waitFrom(3);
        } else if (id == 1) {
            waitFrom(0);
            sendTo(2);
        } else if (id == 2) {
            waitFrom(1);
            sendTo(3);
        } else if (id == 3) {
            waitFrom(2);
            sendTo(0);
        }
    }

    // Méthode pour gérer la deuxième itération.
    private static void iteration2() throws IOException {
        if (id == 0) {
            sendTo(2);
            waitFrom(2);
        } else if (id == 1) {
            sendTo(3);
            waitFrom(3);
        } else if (id == 2) {
            waitFrom(0);
            sendTo(0);
        } else if (id == 3) {
            waitFrom(1);
            sendTo(1);
        }
    }

    // Méthode pour gérer la troisième itération.
    private static void iteration3() throws IOException {
        if (id == 0) {
            sendTo(3);
            waitFrom(1);
        } else if (id == 1) {
            sendTo(0);
            waitFrom(2);
        } else if (id == 2) {
            sendTo(1);
            waitFrom(3);
        } else if (id == 3) {
            waitFrom(0);
            sendTo(2);
        }
    }

    // Méthode pour gérer la quatrième itération.
    private static void iteration4() throws IOException {
        if (id == 0) {
            sendTo(1);
            waitFrom(3);
        } else if (id == 1) {
            waitFrom(0);
            sendTo(2);
        } else if (id == 2) {
            waitFrom(1);
            sendTo(3);
        } else if (id == 3) {
            waitFrom(2);
            sendTo(0);
        }
    }

    // Méthode pour envoyer un message à un autre client identifié par targetId.
    private static void sendTo(int targetId) throws IOException {
        // Création d'une connexion à l'autre client.
        Socket s = new Socket("localhost", 2000 + targetId);
        PrintWriter out = new PrintWriter(s.getOutputStream(), true);
        // Incrémentation de l'horloge logique avant d'envoyer le message.
        logicalClock++; // incrément avant envoi
        // Envoi du message avec l'identifiant du client et l'horloge logique.
        out.println("FROM " + id + " CLOCK " + logicalClock);
        s.close();
        // Affichage du message envoyé.
        System.out.println("Client " + id + " a envoye un message à " + targetId + " [horloge: " + logicalClock + "]");
    }

    // Méthode pour attendre la réception d'un message d'un autre client.
    private static void waitFrom(int sourceId) {
        System.out.println("Client " + id + " attend un message de " + sourceId);
        synchronized (lock) {
            while (!messageReceived) {
                try {
                    // Le client attend le signal d'un message reçu.
                    lock.wait(); // Bloque tant que le message n'est pas reçu
                } catch (InterruptedException ignored) {}
            }
            // Réinitialisation du statut du message reçu pour la prochaine itération.
            messageReceived = false;
        }
    }

    // Classe interne pour gérer les connexions des pairs (autres clients).
    static class PeerHandler implements Runnable {
        private final Socket socket;

        // Constructeur de la classe qui prend la socket du pair.
        public PeerHandler(Socket socket) {
            this.socket = socket;
        }

        // Méthode pour traiter les messages reçus du pair.
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String msg = in.readLine();

                // Extraction de l'horloge logique du message reçu.
                int receivedClock = extractClock(msg);
                logicalClock = Math.max(logicalClock, receivedClock) + 1;

                System.out.println("Client " + id + " a recu: \"" + msg + "\" [nouvelle horloge: " + logicalClock + "]");
                synchronized (lock) {
                    // Signal que le message a été reçu.
                    messageReceived = true;
                    lock.notify();
                }
                
                // Fermeture de la connexion après traitement.
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Méthode pour extraire l'horloge du message reçu.
        private int extractClock(String msg) {
            try {
                // Division du message pour extraire l'horloge logique.
                String[] parts = msg.split("CLOCK");
                return Integer.parseInt(parts[1].trim());
            } catch (Exception e) {
                return logicalClock;
            }
        }
    }
}
