// Importation des bibliothèques nécessaires pour les opérations d'entrées/sorties, de communication réseau et de gestion des collections.
import java.io.*;
import java.net.*;
import java.util.*;

public class server {
    // Définition du port sur lequel le serveur écoutera les connexions.
    private static final int PORT = 12345;
    // Définition du nombre de clients que le serveur attend.
    private static final int NUM_CLIENTS = 4;
    // Liste pour stocker les sockets des clients connectés.
    private static List<Socket> clients = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        // Création d'un objet ServerSocket qui attendra les connexions sur le port spécifié.
        ServerSocket serverSocket = new ServerSocket(PORT);
        // Affichage d'un message pour indiquer que le serveur est démarré et attend des connexions.
        System.out.println("Serveur demarre. En attente de " + NUM_CLIENTS + " clients...");

        // Boucle pour accepter les connexions des clients jusqu'à ce que le nombre de clients atteigne NUM_CLIENTS.
        while (clients.size() < NUM_CLIENTS) {
            // Acceptation de la connexion d'un client.
            Socket client = serverSocket.accept();
            // Ajout du client à la liste des clients connectés.
            clients.add(client);
            // Affichage de l'adresse IP du client connecté.
            System.out.println("Client connecte: " + client.getInetAddress());
        }

        // Boucle pour effectuer 5 itérations de communication avec les clients.
        for (int iteration = 1; iteration <= 5; iteration++) {
            // Affichage du début de l'itération actuelle.
            System.out.println("Debut de literation " + iteration);
            // Envoi du message "START <iteration>" à tous les clients pour démarrer l'itération.
            broadcast("START " + iteration);

            try { 
                // Pause de 2 secondes pour simuler un délai entre les messages.
                Thread.sleep(2000); 
            } catch (InterruptedException ignored) {}

            // Envoi du message "NEXT" à tous les clients pour indiquer qu'ils peuvent passer à l'étape suivante.
            broadcast("NEXT");
            // Affichage de la fin de l'itération.
            System.out.println("Fin de literation " + iteration);
        }

        // Envoi du message "END" à tous les clients pour signaler la fin de la communication.
        broadcast("END");
        
        // Fermeture de la connexion avec chaque client.
        for (Socket client : clients) client.close();
        // Fermeture du serveur une fois toutes les connexions fermées.
        serverSocket.close();
    }

    // Méthode pour envoyer un message à tous les clients connectés.
    private static void broadcast(String message) {
        // Parcours de la liste des clients.
        for (Socket client : clients) {
            try {
                // Création d'un PrintWriter pour envoyer le message au client via son flux de sortie.
                new PrintWriter(client.getOutputStream(), true).println(message);
            } catch (IOException e) {
                // En cas d'erreur lors de l'envoi du message, afficher la pile des erreurs.
                e.printStackTrace();
            }
        }
    }
}
