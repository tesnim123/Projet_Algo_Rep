// Importation des bibliothèques nécessaires pour les opérations d'entrées/sorties, la gestion des sockets et des collections.
import java.io.*;
import java.net.*;
import java.util.*;

public class ServerV {
    // Définition du port pour la connexion du serveur.
    private static final int PORT = 12345;
    // Définition du nombre de clients à connecter au serveur.
    private static final int NUM_CLIENTS = 4;
    // Liste qui contiendra les sockets des clients connectés.
    private static List<Socket> clients = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        // Création du ServerSocket pour écouter les connexions entrantes sur le port spécifié.
        ServerSocket serverSocket = new ServerSocket(PORT);
        System.out.println("Serveur demarre. En attente de " + NUM_CLIENTS + " clients...");

        // Boucle pour accepter les connexions des clients jusqu'à ce que le nombre de clients soit atteint.
        while (clients.size() < NUM_CLIENTS) {
            // Le serveur accepte une connexion d'un client.
            Socket client = serverSocket.accept();
            // Ajout du client à la liste des clients connectés.
            clients.add(client);
            System.out.println("Client connecte: " + client.getInetAddress());
        }

        // Boucle pour gérer les itérations (5 itérations au total).
        for (int iteration = 1; iteration <= 5; iteration++) {
            System.out.println("Debut de literation " + iteration);
            // Diffusion du message "START" avec l'itération courante à tous les clients.
            broadcast("START " + iteration);

            // Pause de 2 secondes avant la prochaine action.
            try { Thread.sleep(2000); } catch (InterruptedException ignored) {}

            // Diffusion du message "NEXT" à tous les clients pour signaler la progression.
            broadcast("NEXT");
            System.out.println("Fin de literation " + iteration);
        }

        // Envoi du message "END" à tous les clients pour terminer le processus.
        broadcast("END");
        // Fermeture des connexions de tous les clients.
        for (Socket client : clients) client.close();
        // Fermeture du ServerSocket une fois que toutes les connexions sont fermées.
        serverSocket.close();
    }

    // Méthode pour envoyer un message à tous les clients connectés.
    private static void broadcast(String message) {
        // Parcours de la liste des clients et envoi du message à chaque client.
        for (Socket client : clients) {
            try {
                // Création d'un PrintWriter pour envoyer un message via la sortie du socket du client.
                new PrintWriter(client.getOutputStream(), true).println(message);
            } catch (IOException e) {
                // Gestion des erreurs d'entrée/sortie lors de l'envoi du message.
                e.printStackTrace();
            }
        }
    }
}
