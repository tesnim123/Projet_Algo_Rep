// Importation des bibliothèques nécessaires pour les opérations d'entrées/sorties, la gestion des sockets, etc.
import java.io.*;
import java.net.*;

public class ClientM {
    // Adresse et port du serveur auquel le client va se connecter.
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;
    // Nombre total de clients.
    private static final int N = 4; 
    // Objet de verrouillage pour gérer la synchronisation des threads.
    private static final Object lock = new Object();
    // Indicateur pour savoir si un message a été reçu ou non.
    private static boolean messageReceived = false;

    // Identifiant du client.
    private static int id;
    // Socket utilisé pour accepter des connexions de pairs.
    private static ServerSocket selfSocket;
    // Flux de sortie pour envoyer des messages au serveur.
    private static PrintWriter serverOut;

    // Horloge matricielle locale du client.
    private static int[][] HMi = new int[N][N];

    public static void main(String[] args) throws IOException {
        // Récupération de l'identifiant du client depuis les arguments de la ligne de commande.
        id = Integer.parseInt(args[0]);
        System.out.println("Client " + id + " demarre");

        // Connexion au serveur via un socket.
        Socket serverSocket = new Socket(SERVER_ADDRESS, SERVER_PORT);
        BufferedReader serverIn = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
        serverOut = new PrintWriter(serverSocket.getOutputStream(), true);

        // Création d'un ServerSocket pour accepter des connexions des autres clients (pairs).
        selfSocket = new ServerSocket(2000 + id);
        // Lancement d'un thread pour gérer les connexions des pairs.
        new Thread(() -> {
            while (true) {
                try {
                    Socket peer = selfSocket.accept();
                    new Thread(new PeerHandler(peer)).start();
                } catch (IOException ignored) {}
            }
        }).start();

        // Boucle principale pour lire les messages venant du serveur.
        while (true) {
            String msg = serverIn.readLine();
            if (msg == null || msg.equals("END")) break; // Sortie si le message est null ou "END".

            if (msg.startsWith("START")) { // Si le message commence par "START".
                int iteration = Integer.parseInt(msg.split(" ")[1]);
                handleIteration(iteration); // Gérer l'itération correspondante.
            }
        }

        // Fermeture des connexions.
        serverSocket.close();
        selfSocket.close();
    }

    // Méthode pour gérer chaque itération, en fonction de l'itération reçue.
    private static void handleIteration(int iteration) {
        System.out.println("Client " + id + " commence iteration " + iteration);

        // Événement local : incrément de l'horloge matricielle pour l'auto-clock.
        HMi[id][id]++;
        printClock("Instruction locale");

        try {
            // Appel de la méthode correspondant à l'itération actuelle.
            if (iteration == 1) iteration1();
            else if (iteration == 2) iteration2();
            else if (iteration == 3) iteration3();
            else if (iteration == 4) iteration4();

            // Envoi de la confirmation "DONE" au serveur.
            serverOut.println("DONE");
        } catch (Exception e) {
            e.printStackTrace(); // Gestion des exceptions.
        }
    }

    // Méthodes pour chaque itération spécifique (les actions varient selon l'id du client).
    private static void iteration1() throws IOException {
        if (id == 0) {
            sendTo(1);
            waitFrom(3);
        } else if (id == 1) {
            waitFrom(0);
            sendTo(2);
        } else if (id == 2) {
            waitFrom(1);
            sendTo(3);
        } else if (id == 3) {
            waitFrom(2);
            sendTo(0);
        }
    }

    private static void iteration2() throws IOException {
        if (id == 0) {
            sendTo(2);
            waitFrom(2);
        } else if (id == 1) {
            sendTo(3);
            waitFrom(3);
        } else if (id == 2) {
            waitFrom(0);
            sendTo(0);
        } else if (id == 3) {
            waitFrom(1);
            sendTo(1);
        }
    }

    private static void iteration3() throws IOException {
        if (id == 0) {
            sendTo(3);
            waitFrom(1);
        } else if (id == 1) {
            sendTo(0);
            waitFrom(2);
        } else if (id == 2) {
            sendTo(1);
            waitFrom(3);
        } else if (id == 3) {
            waitFrom(0);
            sendTo(2);
        }
    }

    private static void iteration4() throws IOException {
        if (id == 0) {
            sendTo(1);
            waitFrom(3);
        } else if (id == 1) {
            waitFrom(0);
            sendTo(2);
        } else if (id == 2) {
            waitFrom(1);
            sendTo(3);
        } else if (id == 3) {
            waitFrom(2);
            sendTo(0);
        }
    }

    // Méthode pour envoyer un message à un client spécifié.
    private static void sendTo(int targetId) throws IOException {
        Socket s = new Socket("localhost", 2000 + targetId); // Connexion à la socket du client cible.
        PrintWriter out = new PrintWriter(s.getOutputStream(), true);

        // Incrémentation de l'horloge matricielle locale avant l'envoi.
        HMi[id][id]++;
        HMi[id][targetId]++;

        // Création d'une copie de la matrice d'horloge pour l'envoi.
        int[][] Em = copyMatrix(HMi);
        

        // Construction du message à envoyer.
        StringBuilder msg = new StringBuilder("FROM " + id + " EM ");
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                msg.append(Em[i][j]).append(" ");

        // Envoi du message.
        out.println(msg.toString().trim());
        s.close();

        // Affichage de l'horloge matricielle envoyée.
        System.out.println("Client " + id + " Envoi a " + targetId + " [horloge matricielle]:");
        printMatrix(Em);
    }

    // Méthode pour attendre un message d'un client spécifié.
    private static void waitFrom(int sourceId) {
        System.out.println("Client " + id + " attend un message de " + sourceId);
        synchronized (lock) {
            while (!messageReceived) {
                try {
                    lock.wait(); // Attente du message.
                } catch (InterruptedException ignored) {}
            }
            messageReceived = false; // Réinitialisation de l'indicateur après réception du message.
        }
    }

    // Classe interne pour gérer la réception des messages des autres clients (pairs).
    static class PeerHandler implements Runnable {
        private final Socket socket;

        public PeerHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String msg = in.readLine(); // Lecture du message.

                String[] parts = msg.split(" ");
                int sender = Integer.parseInt(parts[1]); // Identifiant du client expéditeur.
                int[][] Em = new int[N][N]; // Matrice d'horloge envoyée par le client expéditeur.
                int idx = 3;
                for (int i = 0; i < N; i++)
                    for (int j = 0; j < N; j++)
                        Em[i][j] = Integer.parseInt(parts[idx++]);

                

                // Mise à jour de l'horloge matricielle locale.
                HMi[id][id]++;
                HMi[id][sender] = HMi[id][sender] + 1;

                // Fusion de la matrice d'horloge envoyée avec l'horloge locale.
                for (int k = 0; k < N; k++) {
                    
                    for (int l = 0; l < N; l++) {
                        
                        HMi[k][l] = Math.max(HMi[k][l], Em[k][l]);
                    }
                }

                // Affichage de la matrice après la mise à jour.
                System.out.println("Client " + id + " a recu: \"" + msg + "\" [nouvelle horloge matricielle]:");
                printMatrix(HMi);

                // Notification à l'autre thread que le message a été reçu.
                synchronized (lock) {
                    messageReceived = true;
                    lock.notify();
                }

                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Vérifie si un message peut être délivré en respectant les conditions de causalité.
        private boolean canDeliver(int[][] Em, int sender) {
            for (int k = 0; k < N; k++) {
                if (k == id || k == sender) continue;
                if (Em[k][id] > HMi[k][id]) return false;
            }
            return true;
        }
    }

    // Méthode pour faire une copie d'une matrice d'horloge.
    private static int[][] copyMatrix(int[][] original) {
        int[][] copy = new int[N][N];
        for (int i = 0; i < N; i++)
            System.arraycopy(original[i], 0, copy[i], 0, N);
        return copy;
    }

    // Méthode pour afficher une matrice.
    private static void printMatrix(int[][] mat) {
        for (int[] row : mat) {
            System.out.print("  ");
            for (int v : row)
                System.out.print(v + " ");
            System.out.println();
        }
    }

    // Méthode pour afficher l'horloge matricielle avec un label.
    private static void printClock(String label) {
        System.out.println("Client " + id + " " + label + " [horloge matricielle]:");
        printMatrix(HMi);
    }
}
