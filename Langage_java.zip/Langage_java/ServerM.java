// Importation des bibliothèques nécessaires pour les opérations d'entrées/sorties, la gestion des sockets et des collections.
import java.io.*;
import java.net.*;
import java.util.*;

public class ServerM {
    // Port sur lequel le serveur écoute pour les connexions des clients.
    private static final int PORT = 12345;
    // Nombre de clients à accepter.
    private static final int NUM_CLIENTS = 4;
    // Liste pour garder une trace des clients connectés.
    private static List<Socket> clients = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        // Création d'un ServerSocket pour accepter les connexions des clients sur le port spécifié.
        ServerSocket serverSocket = new ServerSocket(PORT);
        System.out.println("Serveur matriciel demarre. En attente de " + NUM_CLIENTS + " clients...");

        // Attente des connexions des clients.
        while (clients.size() < NUM_CLIENTS) {
            Socket client = serverSocket.accept(); // Acceptation de la connexion d'un client.
            clients.add(client); // Ajout du client à la liste des clients.
            System.out.println("Client connecte: " + client.getInetAddress()); // Affichage de l'adresse du client connecté.
        }

        // Démarrage de 5 itérations pour envoyer des messages aux clients.
        for (int iteration = 1; iteration <= 5; iteration++) {
            System.out.println("Debut de literation " + iteration);
            // Envoi du message "START <iteration>" à tous les clients.
            broadcast("START " + iteration);

            try { 
                // Attente de 2 secondes avant de passer à l'itération suivante.
                Thread.sleep(2000); 
            } catch (InterruptedException ignored) {}

            // Envoi du message "NEXT" à tous les clients après la pause.
            broadcast("NEXT");
            System.out.println("Fin de literation " + iteration);
        }

        // Envoi du message "END" pour signaler la fin de la communication.
        broadcast("END");
        
        // Fermeture de la connexion avec tous les clients.
        for (Socket client : clients) client.close();
        // Fermeture du ServerSocket.
        serverSocket.close();
    }

    // Méthode pour envoyer un message à tous les clients connectés.
    private static void broadcast(String message) {
        for (Socket client : clients) {
            try {
                // Création d'un PrintWriter pour envoyer le message au client via son flux de sortie.
                new PrintWriter(client.getOutputStream(), true).println(message);
            } catch (IOException e) {
                e.printStackTrace(); // Gestion des erreurs lors de l'envoi.
            }
        }
    }
}
