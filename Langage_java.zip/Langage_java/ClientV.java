// Importation des bibliothèques nécessaires pour les opérations d'entrées/sorties, la gestion des sockets et des collections.
import java.io.*;
import java.net.*;

public class ClientV {
    // Adresse du serveur et port utilisé pour la communication avec le serveur.
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;
    private static PrintWriter serverOut; // Flux de sortie pour communiquer avec le serveur.

    // Verrou pour synchroniser les messages reçus.
    private static final Object lock = new Object();
    private static boolean messageReceived = false; // Indicateur pour savoir si un message a été reçu.

    // Identifiant unique du client (extrait des arguments de la ligne de commande).
    private static int id;
    private static final int N = 4; // Nombre de clients (vecteur d'horloge pour chaque client).
    private static int[] vectorClock = new int[N]; // Vecteur d'horloge de Lamport.
    private static ServerSocket selfSocket; // Serveur pour accepter les connexions des autres clients.

    public static void main(String[] args) throws IOException {
        // Initialisation de l'identifiant du client à partir des arguments passés.
        id = Integer.parseInt(args[0]);
        System.out.println("Client " + id + " demarre");

        // Connexion au serveur pour recevoir les messages de synchronisation.
        Socket serverSocket = new Socket(SERVER_ADDRESS, SERVER_PORT);
        BufferedReader serverIn = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
        serverOut = new PrintWriter(serverSocket.getOutputStream(), true);

        // Création d'un ServerSocket pour chaque client afin de recevoir des messages d'autres clients.
        int clientPort = 2000 + id;
        selfSocket = new ServerSocket(clientPort);
        // Lancement d'un thread pour accepter les connexions entrantes des autres clients.
        new Thread(() -> {
            while (true) {
                try {
                    Socket peer = selfSocket.accept(); // Attente d'une connexion.
                    new Thread(new PeerHandler(peer)).start(); // Traitement de la connexion dans un nouveau thread.
                } catch (IOException ignored) {}
            }
        }).start();

        // Boucle pour traiter les messages reçus du serveur.
        while (true) {
            String msg = serverIn.readLine();
            if (msg == null || msg.equals("END")) break; // Fin de la communication.

            if (msg.startsWith("START")) { // Si le message est "START", on traite l'itération.
                int iteration = Integer.parseInt(msg.split(" ")[1]);
                handleIteration(iteration); // Traitement de l'itération.
            }
        }

        // Fermeture des sockets après la fin des communications.
        serverSocket.close();
        selfSocket.close();
    }

    // Méthode pour gérer l'itération et la mise à jour de l'horloge vectorielle.
    private static void handleIteration(int iteration) {
        vectorClock[id]++; // Mise à jour de l'horloge du client local.
        System.out.println("Client " + id + " commence literation " + iteration);
        System.out.println("Client " + id + " instruction locale [horloge: " + formatClock() + "]");

        try {
            // Traitement spécifique pour chaque itération.
            if (iteration == 1) iteration1();
            else if (iteration == 2) iteration2();
            else if (iteration == 3) iteration3();
            else if (iteration == 4) iteration4();
            else if (iteration == 5) {} // Pas de communication pour l'itération 5, uniquement local.

            // Envoi de la notification de fin d'itération au serveur.
            serverOut.println("DONE");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Méthodes pour gérer les différentes étapes des itérations, en envoyant et recevant des messages.
    private static void iteration1() throws IOException {
        if (id == 0) { sendTo(1); waitFrom(3); }
        else if (id == 1) { waitFrom(0); sendTo(2); }
        else if (id == 2) { waitFrom(1); sendTo(3); }
        else if (id == 3) { waitFrom(2); sendTo(0); }
    }

    private static void iteration2() throws IOException {
        if (id == 0) { sendTo(2); waitFrom(2); }
        else if (id == 1) { sendTo(3); waitFrom(3); }
        else if (id == 2) { waitFrom(0); sendTo(0); }
        else if (id == 3) { waitFrom(1); sendTo(1); }
    }

    private static void iteration3() throws IOException {
        if (id == 0) { sendTo(3); waitFrom(1); }
        else if (id == 1) { sendTo(0); waitFrom(2); }
        else if (id == 2) { sendTo(1); waitFrom(3); }
        else if (id == 3) { waitFrom(0); sendTo(2); }
    }

    private static void iteration4() throws IOException {
        if (id == 0) { sendTo(1); waitFrom(3); }
        else if (id == 1) { waitFrom(0); sendTo(2); }
        else if (id == 2) { waitFrom(1); sendTo(3); }
        else if (id == 3) { waitFrom(2); sendTo(0); }
    }

    // Méthode pour envoyer un message à un autre client avec mise à jour de l'horloge vectorielle.
    private static void sendTo(int targetId) throws IOException {
        vectorClock[id]++; // Incrément de l'horloge avant l'envoi.
        Socket s = new Socket("localhost", 2000 + targetId); // Connexion au client cible.
        PrintWriter out = new PrintWriter(s.getOutputStream(), true);

        // Création du message à envoyer, avec le vecteur d'horloge complet.
        StringBuilder msg = new StringBuilder("FROM " + id + " CLOCK");
        for (int v : vectorClock) msg.append(" ").append(v);
        out.println(msg.toString());

        System.out.println("Client " + id + " a envoye un message à " + targetId + " [horloge: " + formatClock() + "]");
        s.close();
    }

    // Méthode pour attendre un message d'un autre client.
    private static void waitFrom(int sourceId) {
        System.out.println("Client " + id + " attend un message de " + sourceId);
        synchronized (lock) {
            while (!messageReceived) {
                try { lock.wait(); } catch (InterruptedException ignored) {} // Attente du message.
            }
            messageReceived = false; // Réinitialisation de l'indicateur après réception.
        }
    }

    // Méthode pour formater le vecteur d'horloge sous forme de chaîne.
    private static String formatClock() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < N; i++) {
            sb.append(vectorClock[i]);
            if (i < N - 1) sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }

    // Classe interne pour gérer la réception de messages d'un autre client.
    static class PeerHandler implements Runnable {
        private final Socket socket;

        public PeerHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String msg = in.readLine(); // Lecture du message.

                // Extraction et mise à jour de l'horloge vectorielle.
                int[] receivedClock = extractClock(msg);
                for (int i = 0; i < N; i++) {
                    vectorClock[i] = Math.max(vectorClock[i], receivedClock[i]);
                }
                vectorClock[id]++; // Mise à jour de l'horloge locale après réception.

                System.out.println("Client " + id + " a recu: \"" + msg + "\" [nouvelle horloge: " + formatClock() + "]");
                synchronized (lock) {
                    messageReceived = true; // Marque le message comme reçu.
                    lock.notify(); // Notifie le thread principal.
                }

                socket.close(); // Fermeture de la connexion.
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Méthode pour extraire l'horloge d'un message reçu.
        private int[] extractClock(String msg) {
            int[] result = new int[N];
            try {
                String[] parts = msg.split("CLOCK")[1].trim().split(" ");
                for (int i = 0; i < N; i++) {
                    result[i] = Integer.parseInt(parts[i]); // Parse les valeurs du vecteur d'horloge.
                }
            } catch (Exception e) {
                // Si l'horloge est invalide, renvoie l'horloge locale.
                System.arraycopy(vectorClock, 0, result, 0, N);
            }
            return result;
        }
    }
}
